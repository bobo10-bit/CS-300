// Christopher Wilson
// CS 300 Project 2
// 4/16/2025

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

// structure to hold course information
struct Course {
    string courseNumber;
    string title;
    vector<string> prerequisites;

    Course() {}
    Course(string num, string t, vector<string> prereqs) :
        courseNumber(num), title(t), prerequisites(prereqs) {
    }
};

struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a course
    Node(Course aCourse) : Node() {
        course = aCourse;
    }
};

// Binary Search Tree class
class BinarySearchTree {
private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);
    void destroyTree(Node* node);
    Node* removeNode(Node* node, string courseNumber);
    Node* searchNode(Node* node, const string& courseNumber) const;
public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Course course);
    void Remove(string courseNumber);
    Course Search(const string& courseNumber) const;
};

// Default constructor
BinarySearchTree::BinarySearchTree() {
    root = nullptr;
}

// Destructor
BinarySearchTree::~BinarySearchTree() {
    destroyTree(root);
}

void BinarySearchTree::destroyTree(Node* node) {
    if (node != nullptr) {
        destroyTree(node->left);
        destroyTree(node->right);
        delete node;
    }
}

// Traverse the tree in order
void BinarySearchTree::InOrder() {
    inOrder(root);
}

// Insert a course
void BinarySearchTree::Insert(Course course) {
    if (root == nullptr) {
        root = new Node(course);
    }
    else {
        addNode(root, course);
    }
}

// Remove a course
Node* BinarySearchTree::searchNode(Node* node, const string& courseNumber) const {
    if (node == nullptr || node->course.courseNumber == courseNumber) {
        return node;
    }

    if (courseNumber < node->course.courseNumber) {
        return searchNode(node->left, courseNumber);
    }
    else {
        return searchNode(node->right, courseNumber);
    }
}

Course BinarySearchTree::Search(const string& courseNumber) const {
    Node* foundNode = searchNode(root, courseNumber);
    if (foundNode != nullptr) {
        return foundNode->course;
    }
    return Course();
}

// Add a course to some node (recursive)
void BinarySearchTree::addNode(Node* node, Course course) {
    if (node->course.courseNumber.compare(course.courseNumber) > 0) {
        if (node->left == nullptr) {
            node->left = new Node(course);
        }
        else {
            addNode(node->left, course);
        }
    }
    else {
        if (node->right == nullptr) {
            node->right = new Node(course);
        }
        else {
            addNode(node->right, course);
        }
    }
}

void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) {
        inOrder(node->left);
        cout << node->course.courseNumber << ", " << node->course.title << endl;
        inOrder(node->right);
    }
}


// Remove a node 
Node* BinarySearchTree::removeNode(Node* node, string courseNumber) {
    if (node == nullptr) {
        return node;
    }

    if (courseNumber.compare(node->course.courseNumber) < 0) {
        node->left = removeNode(node->left, courseNumber);
    }
    else if (courseNumber.compare(node->course.courseNumber) > 0) {
        node->right = removeNode(node->right, courseNumber);
    }
    else {
        // Node with only one child or no child
        if (node->left == nullptr) {
            Node* temp = node->right;
            delete node;
            return temp;
        }
        else if (node->right == nullptr) {
            Node* temp = node->left;
            delete node;
            return temp;
        }

       
        Node* temp = node->right;
        while (temp->left != nullptr) {
            temp = temp->left;
        }

        node->course = temp->course;
        node->right = removeNode(node->right, temp->course.courseNumber);
    }
    return node;
}


// Split a string into tokens based on delimiter
vector<string> split(const string& s, char delimiter) {
    vector<string> tokens;
    string token;
    size_t start = 0;
    size_t end = s.find(delimiter);

    while (end != string::npos) {
        token = s.substr(start, end - start);
        tokens.push_back(token);
        start = end + 1;
        end = s.find(delimiter, start);
    }

    token = s.substr(start);
    tokens.push_back(token);
    return tokens;
}


// Load courses from file into BST
void loadCourses(const string& filename, BinarySearchTree* bst) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: Could not open file " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        vector<string> tokens = split(line, ',');

        if (tokens.size() < 2) {
            cout << "Error: Line has less than two values - " << line << endl;
            continue;
        }

        string courseNumber = tokens[0];
        string title = tokens[1];
        vector<string> prerequisites;

        for (size_t i = 2; i < tokens.size(); ++i) {
            prerequisites.push_back(tokens[i]);
        }

        Course course(courseNumber, title, prerequisites);
        bst->Insert(course);
    }

    file.close();
    cout << "Courses loaded successfully." << endl;
}

// Display course information including prerequisites
void displayCourseInfo(const BinarySearchTree* bst, string courseNumber) {
    Course course = bst->Search(courseNumber);
    if (course.courseNumber.empty()) {
        cout << "Course " << courseNumber << " not found." << endl;
        return;
    }

    cout << course.courseNumber << ", " << course.title << endl;
    if (course.prerequisites.empty()) {
        cout << "No prerequisites for this course." << endl;
    }
    else {
        cout << "Prerequisites: ";
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            Course prereq = bst->Search(course.prerequisites[i]);
            if (!prereq.courseNumber.empty()) {
                cout << prereq.courseNumber << " - " << prereq.title;
                if (i != course.prerequisites.size() - 1) {
                    cout << ", ";
                }
            }
        }
        cout << endl;
    }
}

// Display menu options
void displayMenu() {
    cout << "Menu:" << endl;
    cout << "1. Load Courses" << endl;
    cout << "2. Display All Courses" << endl;
    cout << "3. Print Course" << endl;
    cout << "9. Exit" << endl;
    cout << "Enter choice: ";
}

int main() {
    BinarySearchTree* bst = new BinarySearchTree();
    string filename;
    string courseNumber;
    int choice = 0;

    cout << "Course Planner" << endl;

    while (choice != 9) {
        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
			// Asks for file from user and loads it
            cout << "Enter filename: ";
            cin.ignore(); 
            getline(cin, filename);
            loadCourses(filename, bst);
            break;
        case 2:
            // Display all courses
            cout << "Course List: " << endl;
            bst->InOrder();
            cout << endl;
            break;
        case 3:
			// Display course information
            cout << "What course information would you like: ";
            cin >> courseNumber;
            displayCourseInfo(bst, courseNumber);
            break;
        case 9:
            // Exits program
            cout << "Good bye" << endl;
            break;
        default:
            cout << choice << " is not a valid option." << endl;
            break;
        }
    }
}